<?php $logo = '/plugins/TagirijusBrandKB/Assets/img/tagirijus_logo.svg'; ?>

<img src="<?= $logo ?>">